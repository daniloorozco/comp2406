var http = require('http');
var url = require('url'); 
var WebSocketServer = require('ws').Server; //provides web sockets
var ecStatic = require('ecstatic');  //provides static file server service
//static file server
var server = http.createServer(ecStatic({root: __dirname + '/www'}));
var currentUsers = [];
var ws = new WebSocketServer({server: server});
ws.on('connection', function(w) {
	console.log('Client connected');
  w.on('message',function(msg) {
	  var dataObj = JSON.parse(msg);
	  currentUsers.push(dataObj);
	 console.log('message received from client ',dataObj);
	 w.send(JSON.stringify(dataObj));
  });
  w.on('close',function() {
	  console.log('closing connection');
  });
});

/*function broadcast(msg) {
  wss.clients.forEach(function(client) {
    client.send(msg);
  });
}*/


server.listen(3000);
console.log("Hosted on http://localhost:3000/assignment2.html");