var canvas = document.getElementById('canvas1'); //our drawing canvas
var ctx = canvas.getContext('2d');
/*var boxes = [{x:20,y:20,w:50,h:50},{x:150,y:20,w:50,h:50},{x:300,y:20,w:50,h:50}]; // box objects
boxes.push({x:450,y:20,w:50,h:50});
boxes.push({x:20,y:150,w:50,h:50});
boxes.push({x:150,y:150,w:50,h:50});
boxes.push({x:300,y:150,w:50,h:50});
boxes.push({x:450,y:150,w:50,h:50});
*/

//var boxBeingMoved;
//var clientMovingBox;
var connection = new WebSocket('ws://127.0.0.1:3000');
//var timer;
var user;
var userColor;
var users = [];
connection.onopen = function () {
  
};

// Log errors
connection.onerror = function (error) {
  console.error('WebSocket Error ' + error);
};
// Log messages from the server
connection.onmessage = function(e) {
	users.push(e);
	console.log("message from server ",e);
	add_users();
};

var draw_canvas = function(){
	ctx.fillStyle="white";
	ctx.fillRect(0,0,canvas.width,canvas.height);
}

var add_users = function() {
}

function handle_enter_session_button() {
   //get the user input
    var username = document.getElementById("userTextField1").value;
	var color = document.getElementById("userTextField2").value;
	if(username && username != '') {
		if(color && color != '') {
				var obj = {client: username , userColor: color}
				var user = obj.client;
				var userColour = obj.userColor;
				console.log(username);
				console.log(userColour);
				var objJSON = JSON.stringify(obj);
				document.getElementById("userTextField1").value = '';
				document.getElementById("userTextField2").value = '';
				connection.send(objJSON);
		}
	}
	

}				

//this function is run when the page loads
$(document).ready(function(){
	$(document).onclick = function(){handle_enter_session_button};
	//configure the canvas
	draw_canvas();
	add_users();
});

