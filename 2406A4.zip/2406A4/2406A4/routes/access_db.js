const MongoClient = require('mongodb').MongoClient
const DB_PATH = 'mongodb://localhost:3000/dbRecipes'

MongoClient.connect(DB_PATH, function(err, db){
   if(err) console.log(`FAILED TO CONNECTED TO: ${DB_PATH}`);
   else{
      console.log(`CONNECTED TO: ${DB_PATH}`);
      db.collection("recipes", function(err, collection){
        var cursor = collection.find();
        cursor.each(function(err,document){
           console.log(document);
           if(document == null) db.close();
        });
      });
   }   
});